/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author j8318
 */
public class Viaje {
    public int capacidadCamion;
    private List<Solicitud> solicitudes;
    private int pesoTotal;
    private int volumenTotal;

    public Viaje(int capacidadCamion) {
        this.capacidadCamion = capacidadCamion;
        this.solicitudes = new ArrayList<>();
        this.pesoTotal = 0;
        this.volumenTotal = 0;
    }

    public void agregarSolicitud(Solicitud solicitud) {
        if (pesoTotal + solicitud.getPeso() <= capacidadCamion && volumenTotal + solicitud.getVolumen() <= capacidadCamion) {
            solicitudes.add(solicitud);
            pesoTotal += solicitud.getPeso();
            volumenTotal += solicitud.getVolumen();
        }
    }

    public List<Solicitud> getSolicitudes() {
        return solicitudes;
    }

    public int getPesoTotal() {
        return pesoTotal;
    }

    public int getVolumenTotal() {
        return volumenTotal;
    }
}
