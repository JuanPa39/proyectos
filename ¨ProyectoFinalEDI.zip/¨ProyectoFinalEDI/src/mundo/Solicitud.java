/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author j8318
 */
public class Solicitud implements Comparable<Solicitud> {

    private String ciudad;
    private int peso;
    private int volumen;
    private int prioridad;

    public Solicitud(String ciudad, int peso, int volumen, int prioridad) {
        this.ciudad = ciudad;
        this.peso = peso;
        this.volumen = volumen;
        this.prioridad = prioridad;
    }

    public String getCiudad() {
        return ciudad;
    }

    public int getPeso() {
        return peso;
    }

    public int getVolumen() {
        return volumen;
    }

    public int getPrioridad() {
        return prioridad;
    }

    @Override
    public int compareTo(Solicitud other) {
        // Priorizar por prioridad, peso y volumen
        int priorityComparison = Integer.compare(other.prioridad, this.prioridad);
        if (priorityComparison != 0) {
            return priorityComparison;
        }
        int weightComparison = Integer.compare(this.peso, other.peso);
        if (weightComparison != 0) {
            return weightComparison;
        }
        return Integer.compare(this.volumen, other.volumen);
    }
}
