/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author j8318
 */

public class B {
    
    private C mic;

    public B() {
        mic = new C(9);
    
    }

    public C getMic() {
        return mic;
    }

    public void setMic(C mic) {
        this.mic = mic;
    }

    @Override
    public String toString() {
        return "B{" + "mic=" + mic + '}';
    }
    
    
}
