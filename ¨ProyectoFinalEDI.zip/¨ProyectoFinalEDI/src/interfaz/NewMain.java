/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package interfaz;

import java.util.List;
import java.util.Map;
import controlador.GestorDeEnvios;
import mundo.Solicitud;
import mundo.Viaje;

/**
 *
 * @author j8318
 */
public class NewMain {

    public static void main(String[] args) {
        GestorDeEnvios gestorDeEnvios = new GestorDeEnvios();

        // Agregar solicitudes de ejemplo
        gestorDeEnvios.recibirSolicitud(new Solicitud("Bogotá", 5000, 2000, 1));
        gestorDeEnvios.recibirSolicitud(new Solicitud("Medellín", 3000, 1500, 2));
        gestorDeEnvios.recibirSolicitud(new Solicitud("Cali", 8000, 3000, 3));
        gestorDeEnvios.recibirSolicitud(new Solicitud("Barranquilla", 6000, 2500, 4));

        // Programar los envíos
        gestorDeEnvios.programarEnvios();

        // Obtener los viajes programados
        List<Viaje> viajes = gestorDeEnvios.getViajes();
        for (Viaje viaje : viajes) {
            System.out.println("Viaje:");
            for (Solicitud solicitud : viaje.getSolicitudes()) {
                System.out.println("  - Ciudad: " + solicitud.getCiudad() + ", Peso: " + solicitud.getPeso() + ", Volumen: " + solicitud.getVolumen() + ", Prioridad: " + solicitud.getPrioridad());
            }
            System.out.println("  Peso total: " + viaje.getPesoTotal() + ", Volumen total: " + viaje.getVolumenTotal());
        }

        // Obtener las solicitudes por ciudad
        Map<String, List<Solicitud>> solicitudesPorCiudad = gestorDeEnvios.getSolicitudesPorCiudad();
        for (Map.Entry<String, List<Solicitud>> entry : solicitudesPorCiudad.entrySet()) {
            System.out.println("Solicitudes para la ciudad de " + entry.getKey() + ":");
            for (Solicitud solicitud : entry.getValue()) {
                System.out.println("  - Peso: " + solicitud.getPeso() + ", Volumen: " + solicitud.getVolumen() + ", Prioridad: " + solicitud.getPrioridad());
            }
        }
    }
}

