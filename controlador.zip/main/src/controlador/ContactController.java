package controlador;

import java.util.ArrayList;
import java.util.List;

public class ContactController {
    private List<Contact> contacts;

    public ContactController() {
        contacts = new ArrayList<>();
    }

    public void addContact(String name, String email) {
        Contact newContact = new Contact(name, email);
        contacts.add(newContact);
    }

    public void deleteContact(Contact contact) {
        contacts.remove(contact);
    }

    public List<Contact> getAllContacts() {
        return contacts;
    }
}
