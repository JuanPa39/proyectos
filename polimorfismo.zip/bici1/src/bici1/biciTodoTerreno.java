/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bici1;

/**
 *
 * @author j8318
 */
public class biciTodoTerreno extends bici{
    private int nCambios;
    
    public biciTodoTerreno(int nCambios, String numeroSerial, String modelo, String marca){
        super(numeroSerial, modelo, marca);
        this.nCambios = nCambios;
    }

    public int getnCambios() {
        return nCambios;
    }
    
    
    public String mostrarDatos(){
    return "numeroSerial: " + numeroSerial +"\nmodelo: " + modelo+ "\nmarca: " + marca+
                "\nEl valor es: " + nCambios;
    }
}
