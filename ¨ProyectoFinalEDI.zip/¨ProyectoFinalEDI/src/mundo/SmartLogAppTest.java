/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mundo;

import java.util.List;
import java.util.Map;
import controlador.GestorDeEnvios;

public class SmartLogAppTest {

    public void testReceiveAndScheduleDeliveries() {
        GestorDeEnvios gestorDeEnvios;
        gestorDeEnvios = new GestorDeEnvios();

        // Add sample delivery requests
        gestorDeEnvios.recibirSolicitud(new Solicitud("Bogotá", 5000, 2000, 1));
        gestorDeEnvios.recibirSolicitud(new Solicitud("Medellín", 3000, 1500, 2));
        gestorDeEnvios.recibirSolicitud(new Solicitud("Cali", 8000, 3000, 3));
        gestorDeEnvios.recibirSolicitud(new Solicitud("Barranquilla", 6000, 2500, 4));

        // Schedule the deliveries
        gestorDeEnvios.programarEnvios();

        // Verify the scheduled trips
        List<Viaje> viajes = gestorDeEnvios.getViajes();
        if (viajes.size() != 2) {
            throw new AssertionError("Expected 2 trips, got " + viajes.size());
        }

        Viaje viaje1 = viajes.get(0);
        if (viaje1.getSolicitudes().size() != 3) {
            throw new AssertionError("Expected 3 requests in first trip, got " + viaje1.getSolicitudes().size());
        }
        if (viaje1.getPesoTotal() != 16000) {
            throw new AssertionError("Expected total weight of 16000 in first trip, got " + viaje1.getPesoTotal());
        }
        if (viaje1.getVolumenTotal() != 6500) {
            throw new AssertionError("Expected total volume of 6500 in first trip, got " + viaje1.getVolumenTotal());
        }

        Viaje viaje2 = viajes.get(1);
        if (viaje2.getSolicitudes().size() != 1) {
            throw new AssertionError("Expected 1 request in second trip, got " + viaje2.getSolicitudes().size());
        }
        if (viaje2.getPesoTotal() != 6000) {
            throw new AssertionError("Expected total weight of 6000 in second trip, got " + viaje2.getPesoTotal());
        }
        if (viaje2.getVolumenTotal() != 2500) {
            throw new AssertionError("Expected total volume of 2500 in second trip, got " + viaje2.getVolumenTotal());
        }

        // Verify the requests per city
        Map<String, List<Solicitud>> solicitudesPorCiudad = gestorDeEnvios.getSolicitudesPorCiudad();
        if (solicitudesPorCiudad.size() != 4) {
            throw new AssertionError("Expected 4 cities, got " + solicitudesPorCiudad.size());
        }
        if (solicitudesPorCiudad.get("Bogotá").size() != 1) {
            throw new AssertionError("Expected 1 request for Bogotá, got " + solicitudesPorCiudad.get("Bogotá").size());
        }
        if (solicitudesPorCiudad.get("Medellín").size() != 1) {
            throw new AssertionError("Expected 1 request for Medellín, got " + solicitudesPorCiudad.get("Medellín").size());
        }
        if (solicitudesPorCiudad.get("Cali").size() != 1) {
            throw new AssertionError("Expected 1 request for Cali, got " + solicitudesPorCiudad.get("Cali").size());
        }
        if (solicitudesPorCiudad.get("Barranquilla").size() != 1) {
            throw new AssertionError("Expected 1 request for Barranquilla, got " + solicitudesPorCiudad.get("Barranquilla").size());
        }
    }

}
