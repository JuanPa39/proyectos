/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

public class Condiciones {
    
    public static boolean checkWin(String[][] Tabla, String currentPlayer) {
        // Verificar victoria en direcciones horizontal, vertical y diagonales
        return checkHorizontal(Tabla, currentPlayer)
                || checkVertical(Tabla, currentPlayer)
                || checkDiagonal(Tabla, currentPlayer);
    }

// Verifica si hay cuatro fichas en línea horizontalmente
    public static boolean checkHorizontal(String[][] Tabla, String currentPlayer) {
        for (int i = 0; i < Tabla.length; i++) {
            for (int j = 0; j <= Tabla[i].length - 4; j++) {
                if (Tabla[i][j].equals(currentPlayer)
                        && Tabla[i][j + 1].equals(currentPlayer)
                        && Tabla[i][j + 2].equals(currentPlayer)
                        && Tabla[i][j + 3].equals(currentPlayer)) {
                    return true;
                }
            }
        }
        return false;
    }

// Verifica si hay cuatro fichas en línea verticalmente
    public static boolean checkVertical(String[][] Tabla, String currentPlayer) {
        for (int i = 0; i <= Tabla.length - 4; i++) {
            for (int j = 0; j < Tabla[i].length; j++) {
                if (Tabla[i][j].equals(currentPlayer)
                        && Tabla[i + 1][j].equals(currentPlayer)
                        && Tabla[i + 2][j].equals(currentPlayer)
                        && Tabla[i + 3][j].equals(currentPlayer)) {
                    return true;
                }
            }
        }
        return false;
    }

// Verifica si hay cuatro fichas en línea en diagonales
    public static boolean checkDiagonal(String[][] Tabla, String currentPlayer) {
        // Verificar diagonales hacia la derecha y hacia la izquierda
        for (int i = 0; i <= Tabla.length - 4; i++) {
            for (int j = 0; j <= Tabla[i].length - 4; j++) {
                // Diagonal hacia la derecha
                if (Tabla[i][j].equals(currentPlayer)
                        && Tabla[i + 1][j + 1].equals(currentPlayer)
                        && Tabla[i + 2][j + 2].equals(currentPlayer)
                        && Tabla[i + 3][j + 3].equals(currentPlayer)) {
                    return true;
                }
                // Diagonal hacia la izquierda
                if (Tabla[i][j + 3].equals(currentPlayer)
                        && Tabla[i + 1][j + 2].equals(currentPlayer)
                        && Tabla[i + 2][j + 1].equals(currentPlayer)
                        && Tabla[i + 3][j].equals(currentPlayer)) {
                    return true;
                }
            }
        }
        return false;
    }

    public static boolean isBoardFull(String[][] Tabla) {
        for (int i = 0; i < Tabla.length; i++) {
            for (int j = 0; j < Tabla[i].length; j++) {
                if (Tabla[i][j].equals(" ")) {
                    // Si se encuentra al menos una celda vacía, el tablero no está lleno.
                    return false;
                }
            }
        }
        // Si no se encuentra ninguna celda vacía, el tablero está lleno.
        return true;
    }
    
}
