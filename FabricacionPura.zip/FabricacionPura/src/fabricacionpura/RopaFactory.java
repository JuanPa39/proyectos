/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fabricacionpura;

/**
 *
 * @author j8318
 */
class RopaFactory {
    Camisa crearCamisa(String tipo) {
        if ("verano".equals(tipo)) {
            return new CamisaVerano();
        } else if ("invierno".equals(tipo)) {
            return new CamisaInvierno();
        }
        return null;
    }

    Pantalon crearPantalon(String tipo) {
        if ("verano".equals(tipo)) {
            return new PantalonVerano();
        } else if ("invierno".equals(tipo)) {
            return new PantalonInvierno();
        }
        return null;
    }
}
