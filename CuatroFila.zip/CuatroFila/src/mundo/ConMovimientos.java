/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.Scanner;

public class ConMovimientos {

    // Ejemplo de función getPlayerMove (puedes personalizarla):
   public static int getPlayerMove(String currentPlayer, Scanner sc) {
    int column = -1; // Valor inicial que indica que no se ha seleccionado una columna válida

    while (column < 0 || column > 7) {
        System.out.print(currentPlayer + ", elige una columna (0-6): ");
        String input = sc.next();

        if (input.length() == 1) {
            char inputChar = input.charAt(0);
            if (inputChar >= '0' && inputChar <= '6') {
                column = Character.getNumericValue(inputChar);
            }
        }

        if (column < 0 || column > 6) {
            System.out.println("Entrada no válida. Debes ingresar un número entre 0 y 6.");
        }
    }

    return column;
}

    // Resto de las funciones para verificar condiciones de victoria y empate
    public static boolean isColumnFull(String[][] tabla, int column) {
        if (column < 0 || column >= tabla[0].length) {
            // La columna especificada está fuera de los límites del tablero.
            return true;
        }

        for (int i = 0; i < tabla.length; i++) {
            if (tabla[i][column].equals(" ")) {
                // Si encontramos al menos una celda vacía en la columna, no está llena.
                return false;
            }
        }

        // Si no encontramos celdas vacías en la columna, está llena.
        return true;
    }

    public static void dropPiece(String[][] tabla, int column, String currentPlayer) {
        if (column < 0 || column >= tabla[0].length) {
            // La columna especificada está fuera de los límites del tablero, no se puede colocar la ficha.
            return;
        }

        if (isColumnFull(tabla, column)) {
            System.out.println("La columna está llena. Elige otra columna.");
            return;
        }

        for (int i = tabla.length - 1; i >= 0; i--) {
            if (tabla[i][column].equals(" ")) {
                // Encuentra la primera celda vacía en la columna y coloca la ficha del jugador actual.
                tabla[i][column] = currentPlayer;
                break;
            }
        }
    }

}
