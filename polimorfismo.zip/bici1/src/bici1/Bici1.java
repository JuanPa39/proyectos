

package bici1;

public class Bici1 {

    public static void main(String[] args) {
       bici misBici[] = new bici[4];
       
       misBici[0] = new bici("GBdsFOZNPQ","cross","GW");
       misBici[1] = new biciFixie(28,"GHPontRESX","Publica","Avanti");       
       misBici[2] = new biciPublica(2800,"KAJSKAmsmsJSAIN","Señoritera(Publica)","Aurum");
       misBici[3] = new biciTodoTerreno(9,"KLASJaasxxKHJIUE","Basso", "Avanti");
    
        for (bici bici: misBici) {
            System.out.println(bici.mostrarDatos());
            System.out.println("");
        }
    
    }

}
