/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

public class tablero {

    String[][] tabla = new String[6][7];

    public tablero() {

        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 7; j++) {
                tabla[i][j] = " ";  
            }
        }

    }

    public static void LlenarArreglo(String[][] Tabla) {
        int filas = Tabla.length;
        int columnas = Tabla[0].length;

        System.out.println("  0   1   2   3   4   5   6 ");

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print("| " + Tabla[i][j] + " ");
            }
            System.out.println("|");
            System.out.println("----------------------------");
        }
    }

    public String[][] getTabla() {
        return tabla;
    }


    
    

}
