package co.edu.unipiloto.estdatos.tallerheap.mundo;

import java.util.ArrayList;
import co.edu.unipiloto.estdatos.tallerheap.estructuras.IHeap;

public class Pizzeria {
    // ----------------------------------
    // Constantes
    // ----------------------------------

    public final static String RECIBIR_PEDIDO = "RECIBIR";
    public final static String ATENDER_PEDIDO = "ATENDER";
    public final static String DESPACHAR_PEDIDO = "DESPACHAR";
    public final static String FIN = "FIN";

    // ----------------------------------
    // Atributos
    // ----------------------------------

    /**
     * Heap que almacena los pedidos recibidos
     */
    private IHeap<Pedido> pedidosRecibidos;

    /**
     * Cola de elementos por despachar
     */
    private IHeap<Pedido> pedidosDespachados;

    // ----------------------------------
    // Constructor
    // ----------------------------------

    /**
     * Constructor de la clase Pizzeria
     */
    public Pizzeria() {
        this.pedidosRecibidos = new IHeap<>(); 
        this.pedidosDespachados = new IHeap<>(); 
    }

    // ----------------------------------
    // Métodos
    // ----------------------------------

    /**
     * Agrega un pedido a la cola de prioridad de pedidos recibidos
     * @param nombreAutor nombre del autor del pedido
     * @param precio precio del pedido 
     * @param cercania cercanía del autor del pedido 
     */
    public void agregarPedido(String nombreAutor, double precio, int cercania) {
        Pedido nuevoPedido = new Pedido(nombreAutor, precio, cercania);
        pedidosRecibidos.add(nuevoPedido);
    }

    /**
     * Retorna el próximo pedido en la cola de prioridad o null si no existe.
     * @return p El pedido próximo en la cola de prioridad
     */
    public Pedido atenderPedido() {
        Pedido pedidoAtendido = pedidosRecibidos.poll(); 
        if (pedidoAtendido != null) {
            pedidosDespachados.add(pedidoAtendido);
        }
        return pedidoAtendido;
    }

    /**
     * Despacha al pedido próximo a ser despachado. 
     * @return Pedido próximo pedido a despachar
     */
    public Pedido despacharPedido() {
        return pedidosDespachados.poll(); 
    }

    /**
     * Retorna la cola de prioridad de pedidos recibidos como una lista. 
     * @return list lista de pedidos recibidos.
     */
    public ArrayList<Pedido> pedidosRecibidosList() {
        return new ArrayList<>(pedidosRecibidos.getElements()); 
    }

    /**
     * Retorna la cola de prioridad de despachos como una lista. 
     * @return list cola de prioridad de despachos.
     */
    public ArrayList<Pedido> colaDespachosList() {
        return new ArrayList<>(pedidosDespachados.getElements()); 
    }
}
