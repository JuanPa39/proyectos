
package bici1;

/**
 *
 * @author j8318
 */
public class bici {
    protected String numeroSerial;
    protected String modelo;
    protected String marca;
    
    public bici(String numeroSerial, String modelo, String marca){
           this.numeroSerial = numeroSerial;
           this.modelo = modelo;
           this.marca = marca;
    }

    public String getNumeroSerial() {
        return numeroSerial;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }
    
    public String mostrarDatos(){
        return "numeroSerial: " + numeroSerial +"\nmodelo: " + modelo+ "\nmarca: " + marca;
    }
}

