package interfaz;

import mundo.Dado;



public class InterfazApp {

    public static void main(String[] args) {
   
        
    Dado dado = new Dado();
    
    System.out.println(dado.getFro() + " " + dado.getPos() + "\n" + dado.getIzq() + " " + dado.getDer() + "\n" + dado.getSup() + " " + dado.getInf());
    
    dado.giroEjeX();
    
    System.out.println(dado.getFro() + " " + dado.getPos() + "\n" + dado.getIzq() + " " + dado.getDer() + "\n" + dado.getSup() + " " + dado.getInf());
    
    dado.giroEjeY();
    
    System.out.println(dado.getFro() + " " + dado.getPos() + "\n" + dado.getIzq() + " " + dado.getDer() + "\n" + dado.getSup() + " " + dado.getInf());
    }
    
}
