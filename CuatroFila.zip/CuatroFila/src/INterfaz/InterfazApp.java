package INterfaz;

import java.util.Scanner;
import static mundo.ConMovimientos.dropPiece;
import static mundo.ConMovimientos.getPlayerMove;
import static mundo.ConMovimientos.isColumnFull;
import static mundo.Condiciones.checkWin;
import static mundo.Condiciones.isBoardFull;
import mundo.tablero;
import static mundo.tablero.LlenarArreglo;

public class InterfazApp {


    public static void main(String[] args) {
        tablero tabla = new tablero();
        String[][] Tabla = tabla.getTabla();
        Scanner sc = new Scanner(System.in);
        boolean gameOver = false;
        String currentPlayer = "X";
       

        while (!gameOver) {
            // Mostrar el tablero (implementa esta función)
            LlenarArreglo(Tabla);
            

            // Obtener la columna en la que el jugador desea colocar su ficha (de 1 a 7)
            int column = getPlayerMove(currentPlayer, sc); // Debes declarar e inicializar "column" aquí

            // Verificar si la columna está llena
            if (isColumnFull(Tabla, column)) {
                System.out.println("Columna llena. Intenta de nuevo.");
                continue;
            }

            // Colocar la ficha del jugador en la columna
            dropPiece(Tabla, column, currentPlayer);

            // Verificar si el jugador actual ha ganado
            if (checkWin(Tabla, currentPlayer)) {
                LlenarArreglo(Tabla);
                System.out.println("¡" + currentPlayer + " ha ganado!");
                gameOver = true;
            } else if (isBoardFull(Tabla)) {
                // Verificar si hay un empate (tablero lleno)
                LlenarArreglo(Tabla);
                System.out.println("¡Empate!");
                gameOver = true;
            }

            // Cambiar al siguiente jugador
            currentPlayer = (currentPlayer.equals("X")) ? "O" : "X";
        }
    }
}
