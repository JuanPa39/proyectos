

package Interfaz;

/**
 *
 * @author j8318
 */

import mundo.TortugaLogo;



public class UsaLogo {
    public static void main(String[] args) {
        TortugaLogo tortugaLogo = new TortugaLogo();
        tortugaLogo.efectuar();
        
    }
}

