package co.edu.unipiloto.estdatos.tallerheap.estructuras;

import java.util.ArrayList;
import java.util.List;

public class IHeap<T extends Comparable<T>> implements IHeap<T> {

    private List<T> elements;
    private boolean isMaxHeap;

    public IHeap(boolean isMaxHeap) {
        this.elements = new ArrayList<>();
        this.isMaxHeap = isMaxHeap;
    }

    public void add(T elemento) {
        elements.add(elemento);
        siftUp();
    }

    public T peek() {
        return isEmpty() ? null : elements.get(0);
    }

    public T poll() {
        if (isEmpty()) {
            return null;
        }
        T root = elements.get(0);
        T lastElement = elements.remove(elements.size() - 1);
        if (!isEmpty()) {
            elements.set(0, lastElement);
            siftDown();
        }
        return root;
    }

    public int size() {
        return elements.size();
    }

    public boolean isEmpty() {
        return elements.isEmpty(); 
    }

    public void siftUp() {
        int index = elements.size() - 1;
        while (index > 0) {
            int parentIndex = (index - 1) / 2;
            if (shouldSwap(elements.get(index), elements.get(parentIndex))) {
                T temp = elements.get(index);
                elements.set(index, elements.get(parentIndex));
                elements.set(parentIndex, temp);
                index = parentIndex; 
            } else {
                break;
            }
        }
    }

    public void siftDown() {
        int index = 0;
        int lastIndex = elements.size() - 1;
        while (index < lastIndex) {
            int leftChildIndex = 2 * index + 1;
            int rightChildIndex = 2 * index + 2;
            int targetIndex = index;

            if (leftChildIndex <= lastIndex && shouldSwap(elements.get(leftChildIndex), elements.get(targetIndex))) {
                targetIndex = leftChildIndex; 
            }
            if (rightChildIndex <= lastIndex && shouldSwap(elements.get(rightChildIndex), elements.get(targetIndex))) {
                targetIndex = rightChildIndex; 
            }
            if (targetIndex == index) {
                break;
            }
            T temp = elements.get(index);
            elements.set(index, elements.get(targetIndex));
            elements.set(targetIndex, temp);
            index = targetIndex; 
        }
    }

    private boolean shouldSwap(T child, T parent) {
        return isMaxHeap ? child.compareTo(parent) > 0 : child.compareTo(parent) < 0; 
    }

    public List<T> getElements() {
        return new ArrayList<>(elements); 
    }
}

