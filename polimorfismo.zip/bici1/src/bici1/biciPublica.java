
package bici1;

public class biciPublica extends bici{
     

    private int valor;

    public biciPublica(int valor, String numeroSerial, String modelo, String marca) {
        super(numeroSerial, modelo, marca);
        this.valor = valor;
    }

    public int getTamañoRin() {
        return valor;
    }

    
    public String mostrarDatos(){
        return "numeroSerial: " + numeroSerial +"\nmodelo: " + modelo+ "\nmarca: " + marca+
                "\nEl valor es: " + valor;
    }
}
