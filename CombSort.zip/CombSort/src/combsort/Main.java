/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package combsort;

import static combsort.CombSort.estaOrdenado;
import static combsort.CombSort.sort;

/**
 *
 * @author j8318
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        CombSort gap = new CombSort();
        int[] arreglo = {8, 4, 1, 56, 3, -44, 23, -6, 28, 0, 99, 18, 111, 222, 333 ,25};

        System.out.println("Arreglo original:");
        gap.mostrar(arreglo);

        // Ordenar el arreglo con CombSort
        sort(arreglo);

        System.out.println("Arreglo ordenado:");
        gap.mostrar(arreglo);

        // Verificar si está ordenado
        if (estaOrdenado(arreglo)) {
            System.out.println("El arreglo está correctamente ordenado.");
        } else {
            System.out.println("El arreglo no está ordenado.");
        }
    }
}
