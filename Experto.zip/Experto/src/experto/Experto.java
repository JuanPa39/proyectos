package experto;

import java.util.Scanner;

public class Experto {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int opcion = 0, valor;
        
        System.out.println("¿Cuál es el principio más básico para añadir responsabilidades en una clase?");
        System.out.println("Asignar responsabilidades al experto de la información, es decir, a la clase que tiene la información necesaria para llevar la tarea a cabo.");
        System.out.println("Por ejemplo, consideremos que un hombre vende caramelos en su tienda, la tienda es la clase"
                + " principal que crea los objetos que el hombre vende en su tienda, por ejemplo, "
                + "chocolates de menta, galletas waffer y paletas de limon, cada objeto pertenece a una subclase a la que podriamos"
                + " llamar productos, en ella existen las caracteristicas de cada producto, como su valor, la cantidad que hay, la cantidad vendida,etc");
        System.out.println("Esto nos ayuda a que cada objeto es responsable de guardar su propia información. "
                + "El producto \"Chocolate de menta\" tiene su propia información, sabe cuánto cuesta, la cantidad que hay en la tienda, la cantidad "
                + "vendida, etc, así lo hace cada objeto. ¿No me crees? Utiliza el siguiente menú para saber la información de cualquiera de los "
                + "tres productos o incluso ajustala.");
        
        System.out.println("Cada producto tiene: precio, cantidad en tienda y cantidad vendida");
        
        Productos chocolate_menta, galletas_waffer,paleta_limon;
        chocolate_menta = new Productos();
        galletas_waffer = new Productos();
        paleta_limon = new Productos();
        
        //Set cada caracteristica en cada objeto
        
        //Para chocolate
        chocolate_menta.setNombre("Chocolate de Menta");
        chocolate_menta.setPrecio(2500);
        chocolate_menta.setCantidadActual(25);
        chocolate_menta.setCantidadVendida(23);
        
        //Para Galleta
        galletas_waffer.setNombre("Galletas Waffer");
        galletas_waffer.setPrecio(2200);
        galletas_waffer.setCantidadActual(22);
        galletas_waffer.setCantidadVendida(34);
        
        //Para paleta de limon
        
        paleta_limon.setNombre("Paleta de Limón");
        paleta_limon.setPrecio(1500);
        paleta_limon.setCantidadActual(62);
        paleta_limon.setCantidadVendida(90);
        
        
        do{
            System.out.println("""
                               \u00bfQuieres ver la información o establacerla tu?
                                1. Ver la información del producto 
                                2. Establecer la información del producto""");
            int si_no = sc.nextInt();
            
            switch (si_no) {
                case 1 -> {
                    System.out.println("---- Menú de Opciones ----");
                    // Para chocolate
                    System.out.println("0. Visualizar el precio del chocolate de menta");
                    System.out.println("1. Visualizar la cantidad actual del chocolate de menta");
                    System.out.println("2. Visualizar la cantidad vendida del chocolate de menta");
                    System.out.println("3. Verificar el nombre guardado en el objeto chocolate de menta");
                    // Para galleta
                    System.out.println("4. Visualizar el precio de las galletas Waffer");
                    System.out.println("5. Visualizar la cantidad actual de las galletas Waffer");
                    System.out.println("6. Visualizar la cantidad vendida de las galletas Waffer");
                    System.out.println("7. Verificar el nombre guardado en el objeto galletas Waffer");
                    //Para paleta
                    System.out.println("8. Visualizar el precio del chocolate de menta");
                    System.out.println("9. Visualizar la cantidad actual del chocolate de menta");
                    System.out.println("10. Visualizar la cantidad vendida del chocolate de menta");
                    System.out.println("11. Verificar el nombre guardado en el objeto chocolate de menta");
                    System.out.println("12. Salir");
                    System.out.print("Ingrese su opción: ");
                    opcion = sc.nextInt();
                    
                    switch(opcion){
                        case 0 -> System.out.println(chocolate_menta.getPrecio());
                        case 1 -> System.out.println(chocolate_menta.getCantidadActual());
                        case 2 -> System.out.println(chocolate_menta.getCantidadVendida());
                        case 3 -> System.out.println(chocolate_menta.getNombre());
                        case 4 -> System.out.println(galletas_waffer.getPrecio());
                        case 5 -> System.out.println(galletas_waffer.getCantidadActual());
                        case 6 -> System.out.println(galletas_waffer.getCantidadVendida());
                        case 7 -> System.out.println(galletas_waffer.getNombre());
                        case 8 -> System.out.println(paleta_limon.getPrecio());
                        case 9 -> System.out.println(paleta_limon.getCantidadActual());
                        case 10-> System.out.println(paleta_limon.getCantidadVendida());
                        case 11-> System.out.println(paleta_limon.getNombre());
                        default -> System.out.println("¿Acaso elegiste algo?");
                    }
                }
                case 2 -> {
                    System.out.println("---- Menú de Opciones ----");
                    // Para chocolate
                    System.out.println("0. Establece el precio del chocolate de menta");
                    System.out.println("1. Establece la cantidad actual del chocolate de menta");
                    System.out.println("2. Establece la cantidad vendida del chocolate de menta");
                    // Para galleta
                    System.out.println("3. Establece el precio de las galletas Waffer");
                    System.out.println("4. Establece la cantidad actual de las galletas Waffer");
                    System.out.println("5. Establece la cantidad vendida de las galletas Waffer");
                    //Para paleta
                    System.out.println("6. Establece el precio del chocolate de menta");
                    System.out.println("7. Establece la cantidad actual del chocolate de menta");
                    System.out.println("8. Establece la cantidad vendida del chocolate de menta");
                    System.out.println("12. Salir");
                    System.out.print("Ingrese su opción: ");
                    opcion = sc.nextInt();
                    
                    switch(opcion){
                        case 0:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            chocolate_menta.setPrecio(valor);
                            break;
                        case 1:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            chocolate_menta.setCantidadActual(valor);
                            break;
                        case 2:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            chocolate_menta.setCantidadVendida(valor);
                            break;
                        case 3:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            galletas_waffer.setPrecio(valor);
                            break;
                        case 4:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            galletas_waffer.setCantidadActual(valor);
                            break;
                        case 5:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            galletas_waffer.setCantidadVendida(valor);
                            break;
                        case 6:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            paleta_limon.setPrecio(valor);
                            break;
                        case 7:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            paleta_limon.setCantidadActual(valor);
                            break;
                        case 8:
                            System.out.println("Ingrese el valor a cambiar");
                            valor = sc.nextInt();
                            paleta_limon.setCantidadVendida(valor);
                            break;
                        default: System.out.println("¿Acaso elegiste algo?");
                    }
                }
                default -> { 
                    System.out.println("Adiós.");
                    opcion = 12;
                }
            }
            
        }while(opcion != 12);
        
        
        }
    
}