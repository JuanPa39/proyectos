

package fabricacionpura;

/**
 *
 * @author j8318
 */
public class FabricacionPura {
    public static void main(String[] args) {
        RopaFactory fabrica = new RopaFactory();

        // Crear productos de verano
        Camisa camisaVerano = fabrica.crearCamisa("verano");
        Pantalon pantalonVerano = fabrica.crearPantalon("verano");

        System.out.println("Ropa de verano:");
        System.out.println(camisaVerano.getDescription());
        System.out.println(pantalonVerano.getDescription());

        // Crear productos de invierno
        Camisa camisaInvierno = fabrica.crearCamisa("invierno");
        Pantalon pantalonInvierno = fabrica.crearPantalon("invierno");

        System.out.println("\nRopa de invierno:");
        System.out.println(camisaInvierno.getDescription());
        System.out.println(pantalonInvierno.getDescription());
    }
}
