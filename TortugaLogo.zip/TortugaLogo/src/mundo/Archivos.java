
package mundo;

import java.io.*;

/**
 * La clase Archivos proporciona métodos para trabajar con archivos,
 * incluyendo la creación, escritura, lectura y manipulación de comandos.
 */
public class Archivos {

    /**
     * Agrega un comando al archivo especificado.
     *
     * @param nombreArchivo El nombre del archivo donde se agregará el comando.
     * @param comando El comando a agregar al archivo.
     */
    public void agregarComando(String nombreArchivo, String comando) {
        escribirArchivo(nombreArchivo, comando);
    }

    /**
     * Agrega comandos desde un archivo de origen a un archivo de destino.
     *
     * @param nombreArchivoDestino El nombre del archivo de destino.
     * @param nombreArchivoOrigen El nombre del archivo de origen.
     */
    public void agregarComandoDesdeArchivo(String nombreArchivoDestino, String nombreArchivoOrigen) {
        try {
            BufferedReader entrada = new BufferedReader(new FileReader(nombreArchivoOrigen));
            String lectura = entrada.readLine();

            while (lectura != null) {
                // Agrega cada línea del archivo de origen al archivo de destino
                escribirArchivo(nombreArchivoDestino, lectura);
                lectura = entrada.readLine();
            }

            entrada.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }

    /**
     * Crea un nuevo archivo con el nombre especificado.
     *
     * @param nombre El nombre del nuevo archivo a crear.
     */
    public void crearArchivo(String nombre) {
        File archivo = new File(nombre);
        try {
            PrintWriter salida = new PrintWriter(archivo);
            salida.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        }
    }

    /**
     * Escribe el contenido especificado en el archivo con el nombre dado.
     *
     * @param nombre El nombre del archivo donde se escribirá el contenido.
     * @param contenido El contenido a escribir en el archivo.
     */
    public void escribirArchivo(String nombre, String contenido) {
        File archivo = new File(nombre);

        try {
            PrintWriter salida = new PrintWriter(new FileWriter(archivo, true));
            salida.println(contenido);
            salida.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }

    /**
     * Abre un archivo y ejecuta los comandos en una instancia de la clase TortugaLogo.
     *
     * @param tortuga La instancia de TortugaLogo en la que se ejecutarán los comandos.
     * @param nombre El nombre del archivo a abrir y ejecutar.
     */
    public void abrirArchivo(TortugaLogo tortuga, String nombre) {
        File archivo = new File(nombre);

        try {
            BufferedReader entrada = new BufferedReader(new FileReader(archivo));
            String lectura = entrada.readLine();

            while (lectura != null) {
                // Agregar lógica según el formato de tus comandos
                tortuga.agregarComandoDesdeArchivo(lectura);
                lectura = entrada.readLine();
            }
            entrada.close();
        } catch (FileNotFoundException ex) {
            ex.printStackTrace(System.out);
        } catch (IOException ex) {
            ex.printStackTrace(System.out);
        }
    }
}

