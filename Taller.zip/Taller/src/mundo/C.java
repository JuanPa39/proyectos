/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author j8318
 */
public class C {
    
    private int var;

    public C(int var) {
        this.var = var;
        
    }

    
    
    public int getVar() {
        return var;
    }

    public void setVar(int var) {
        this.var = var;
    }

    @Override
    public String toString() {
        return "C{" + "var=" + var + '}';
    }
 
    
}

