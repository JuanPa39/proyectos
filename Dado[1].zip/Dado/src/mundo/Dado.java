package mundo;

public class Dado {

    //atributos
    private int fro, der, izq, sup, inf, pos;

    //constructores
    public Dado() {
        this.fro = 1;
        this.pos = 6;
        this.izq = 2;
        this.der = 5;
        this.sup = 3;
        this.inf = 4;

    }

    public Dado(int fro, int der, int izq, int sup, int inf, int pos) {
        this.fro = fro;
        this.der = der;
        this.izq = izq;
        this.sup = sup;
        this.inf = inf;
        this.pos = pos;
    }

    //metodos get y set
    public int getFro() {
        return fro;
    }

    public int getDer() {
        return der;
    }

    public int getIzq() {
        return izq;
    }

    public int getSup() {
        return sup;
    }

    public int getInf() {
        return inf;
    }

    public int getPos() {
        return pos;
    }

    public void setFro(int fro) {
        this.fro = fro;
    }

    public void setDer(int der) {
        this.der = der;
    }

    public void setIzq(int izq) {
        this.izq = izq;
    }

    public void setSup(int sup) {
        this.sup = sup;
    }

    public void setInf(int inf) {
        this.inf = inf;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    //metodos funcionales
    public void giroEjeX() {//movimiento del dado de forma horizontal
        switch(this.fro){
            case 1:
                this.fro = 2;
                this.der = 1;
                this.pos = 5;
                this.izq = 6;
            
        }
    }

    public void giroEjeY() {//movimiento del dado de forma vertical
    }

    public void giroEjeZ() {//movimiento del dado de forma transversal
        
    }

    private void validacion() {//validar 

    }

}
