/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

/**
 *
 * @author j8318
 */
public class A {
    
    private B mib;
    private C mic;

    public A(){
    mib = new B();
    mic = new C(10);
    }

    public B getMib() {
        return mib;
    }

    public void setMib(B mib) {
        this.mib = mib;
    }

    public C getMic() {
        return mic;
    }

    public void setMic(C mic) {
        this.mic = mic;
    }

    @Override
    public String toString() {
        return "A{" + "mib=" + mib + ", mic=" + mic + '}';
    }
    
    
    
}
