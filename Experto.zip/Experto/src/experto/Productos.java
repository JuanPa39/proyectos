
package experto;

/**
 *
 * @author Kotaro
 */
public class Productos {
    private String nombre;
    private int precio;
    private int cantidadVendida;
    private int cantidadActual;
    
   public Productos(){
   }

    public String getNombre() {
        return nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public int getCantidadVendida() {
        return cantidadVendida;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public void setCantidadVendida(int cantidadVendida) {
        this.cantidadVendida = cantidadVendida;
    }

    public void setCantidadActual(int cantidadActual) {
        this.cantidadActual = cantidadActual;
    }
   
}
