package mundo;

public class Dado {

    //atributos
    private int fro, der, izq, sup, inf, pos;

    //constructores
    public Dado() {
        this.fro = 2;
        this.pos = 5;
        this.izq = 4;
        this.der = 3;
        this.sup = 1;
        this.inf = 6;

    }

    public Dado(int fro, int der, int izq, int sup, int inf, int pos) {
        this.fro = fro;
        this.der = der;
        this.izq = izq;
        this.sup = sup;
        this.inf = inf;
        this.pos = pos;
    }

    //metodos get y set
    public int getFro() {
        return fro;
    }

    public int getDer() {
        return der;
    }

    public int getIzq() {
        return izq;
    }

    public int getSup() {
        return sup;
    }

    public int getInf() {
        return inf;
    }

    public int getPos() {
        return pos;
    }

    public void setFro(int fro) {
        this.fro = fro;
    }

    public void setDer(int der) {
        this.der = der;
    }

    public void setIzq(int izq) {
        this.izq = izq;
    }

    public void setSup(int sup) {
        this.sup = sup;
    }

    public void setInf(int inf) {
        this.inf = inf;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    //metodos funcionales
    public void giroEjeX() {//movimiento del dado de forma horizontal
       int temp = fro;
        fro = sup;
        sup = pos;
        pos = inf;
        inf = temp;
    }
    
    public void giroEjeY() {//movimiento del dado de forma vertical
        int temp = fro;
        fro = sup;
        sup = pos;
        pos = inf;
        inf = temp;
    }

    public void giroEjeZ() {//movimiento del dado de forma transversal
        int temp = sup;
        sup = izq ;
        izq = inf;
        inf = der;
        der = temp;
    }
// Método para imprimir el estado actual del dado

    public void imprimirEstado() {
        System.out.println("Cara frontal: " + fro);
        System.out.println("Cara derecha: " + der);
        System.out.println("Cara izquierda: " + izq);
        System.out.println("Cara superior: " + sup);
        System.out.println("Cara inferior: " + inf);
        System.out.println("Cara posterior " + pos);
    }
}
