
package controlador;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import mundo.Solicitud;
import mundo.Viaje;

/**
 *
 * @author j8318
 */
public class GestorDeEnvios {

    private PriorityQueue<Solicitud> solicitudesPendientes;
    private List<Viaje> viajes;
    private Map<String, List<Solicitud>> solicitudesPorCiudad;

    public GestorDeEnvios() {
        this.solicitudesPendientes = new PriorityQueue<>();
        this.viajes = new ArrayList<>();
        this.solicitudesPorCiudad = new HashMap<>();
    }

    public void recibirSolicitud(Solicitud solicitud) {
        solicitudesPendientes.offer(solicitud);
        String ciudad = solicitud.getCiudad();
        solicitudesPorCiudad.computeIfAbsent(ciudad, k -> new ArrayList<>())
                .add(solicitud);
    }

    public void programarEnvios() {
        while (!solicitudesPendientes.isEmpty()) {
            Solicitud solicitud = solicitudesPendientes.poll();
            boolean asignada = false;
            for (Viaje viaje : viajes) {
                if (viaje.getPesoTotal() + solicitud.getPeso() <= viaje.capacidadCamion
                        && viaje.getVolumenTotal() + solicitud.getVolumen() <= viaje.capacidadCamion) {
                    viaje.agregarSolicitud(solicitud);
                    asignada = true;
                    break;
                }
            }
            
            if (!asignada) {
                Viaje nuevoViaje = new Viaje(solicitud.getPeso() <= 7000 ? 7000 : 18000);
                nuevoViaje.agregarSolicitud(solicitud);
                viajes.add(nuevoViaje);
            }
        }
    }

    public List<Viaje> getViajes() {
        return viajes;
    }

    public Map<String, List<Solicitud>> getSolicitudesPorCiudad() {
        return solicitudesPorCiudad;
    }
}

