
package bici1;

public class biciFixie extends bici{
    
    private int tamañoRin;

    public biciFixie(int tamañoRin, String numeroSerial, String modelo, String marca) {
        super(numeroSerial, modelo, marca);
        this.tamañoRin = tamañoRin;
    }

    public int getTamañoRin() {
        return tamañoRin;
    }

    
    public String mostrarDatos(){
        return "numeroSerial: " + numeroSerial +"\nmodelo: " + modelo+ "\nmarca: " + marca+
                "\nTamaño del rin: " + tamañoRin;
    }
}
