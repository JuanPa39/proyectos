package Interfaz;

import mundo.A;


public class InterfazApp {

    private A mia;

    public InterfazApp() {
        mia = new A();

    }

    public A getMia() {
        return mia;
    }

    public void setMia(A mia) {
        this.mia = mia;
    }

    @Override
    public String toString() {
        return "InterfazApp{" + "mia=" + mia + '}';
    }

    public static void main(String[] args) {
        InterfazApp iApp = new InterfazApp();
        System.out.println(iApp);
        iApp.getMia().getMib().getMic().setVar(19);
        System.out.println(iApp.getMia().getMib().getMic());

    }

}
