/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mundo;

import java.util.Scanner;

/**
 * La clase TortugaLogo simula el movimiento de una tortuga en un tablero
 * bidimensional y permite realizar diversas operaciones con ella.
 */
public class TortugaLogo {

    private int Ancho = 21;
    private int Alto = 21;
    private int[][] tabla = new int[Alto][Ancho];
    private int x = 0;
    private int y = 0;
    private boolean plumaAbajo = false;
    private Archivos archivos = new Archivos();

    Scanner sc = new Scanner(System.in);

    /**
     * Método principal que inicia la ejecución del programa de Tortuga Logo.
     */
    public void efectuar() {
        int comando;

        do {
            System.out.println("\n=== Tortuga Logo ===");
            System.out.print("Ingrese comando (0 para salir): ");
            imprimirComandos();
            comando = sc.nextInt();

            switch (comando) {
                case 1:
                    levantarPluma();
                    break;
                case 2:
                    bajarPluma();
                    break;
                case 3:
                    mover();
                    break;
                case 4:
                    imprimirTabla();
                    break;
                case 5:
                    imprimirPosicionYDireccion();
                    break;
                case 6:
                    imprimirComandos();
                    break;
                case 7:
                    limpiarTablero();
                    break;
                case 8:
                    borrarCasilla();
                    break;
                case 9:
                    ejecutarComandosDesdeArchivo();
                    break;
                case 10:
                    crearArchivo();
                    break;
                case 11:
                    guardarComandosEnArchivo();
                case 12:
                    ejecutarComandosDesdeArchivoGuardado();
                    break;
                default:
                    System.out.println("Comando inválido. Intente nuevamente.");
            }
        } while (comando != 0);
    }

    /**
     * Ejecuta comandos almacenados en un archivo previamente guardado.
     */
    public void ejecutarComandosDesdeArchivoGuardado() {
        System.out.print("Ingrese el nombre del archivo con los comandos guardados: ");
        String nombreArchivo = sc.next();

        archivos.abrirArchivo(this, nombreArchivo);
    }

    /**
     * Guarda comandos ingresados por el usuario en un archivo.
     */
    public void guardarComandosEnArchivo() {
        System.out.print("Ingrese el nombre del archivo para guardar los comandos: ");
        String nombreArchivo = sc.next();

        System.out.print("Ingrese los comandos separados por comas (por ejemplo, 1,2,3): ");
        String comandos = sc.next();

        String[] comandoArray = comandos.split(",");

        for (String comando : comandoArray) {
            // Agregar cada comando al archivo
            archivos.agregarComando(nombreArchivo, comando);
        }

        System.out.println("Comandos guardados en el archivo: " + nombreArchivo);
    }

    /**
     * Crea un nuevo archivo con el nombre proporcionado por el usuario.
     */
    public void crearArchivo() {
        System.out.print("Ingrese el nombre del archivo: ");
        String nombreArchivo = sc.next();

        archivos.crearArchivo(nombreArchivo);

        System.out.println("Archivo creado: " + nombreArchivo);
    }

    /**
     * Ejecuta comandos almacenados en un archivo externo.
     */
    public void ejecutarComandosDesdeArchivo() {
        System.out.print("Ingrese el nombre del archivo a ejecutar: ");
        String nombreArchivo = sc.next();

        archivos.abrirArchivo(this, nombreArchivo);
    }

    /**
     * Agrega un comando proporcionado desde un archivo al sistema.
     *
     * @param comando El comando a agregar.
     */
    public void agregarComandoDesdeArchivo(String comando) {
        // Adaptar la lógica según el formato de los comandos en tu archivo
        if (comando.equals("levantarPluma")) {
            levantarPluma();
        } else if (comando.equals("bajarPluma")) {
            bajarPluma();
        } else if (comando.startsWith("mover")) {
            // Adaptar la lógica según el formato de los comandos en tu archivo
            String[] partes = comando.split(" ");
            if (partes.length == 3) {
                char direccion = partes[1].charAt(0);
                int pasos = Integer.parseInt(partes[2]);
                moverEnDireccion(direccion, pasos);
            }
        }
    }

    /**
     * Levanta la pluma, indicando que la tortuga no dibujará al moverse.
     */
    public void levantarPluma() {
        System.out.println("La pluma está arriba.");
        plumaAbajo = false;
    }

    /**
     * Baja la pluma, indicando que la tortuga dibujará al moverse.
     */
    public void bajarPluma() {
        System.out.println("La pluma está abajo.");
        plumaAbajo = true;
    }

    /**
     * Mueve la tortuga en la dirección especificada por el usuario.
     */
    public void moverEnDireccion(char direccion, int pasos) {
        switch (direccion) {
            case '6':
                moverDerecha(pasos);
                break;
            case '4':
                moverIzquierda(pasos);
                break;
            case '2':
                moverAbajo(pasos);
                break;
            case '8':
                moverArriba(pasos);
                break;
            case '9':
                moverDiagonalSuperiorDerecha(pasos);
                break;
            case '7':
                moverDiagonalSuperiorIzquierda(pasos);
                break;
            case '3':
                moverDiagonalInferiorDerecha(pasos);
                break;
            case '1':
                moverDiagonalInferiorIzquierda(pasos);
                break;
            default:
                System.out.println("Dirección inválida.");
        }
    }

    /**
     * Mueve la tortuga en una dirección específica.
     */
    public void mover() {
        System.out.print("Ingrese la cantidad de pasos a moverse: ");
        int pasos = sc.nextInt();
        System.out.print("Ingrese la dirección ('6', '4', '2', '8', '9', '7', '3', '1'): ");
        System.out.println(" \n6:Derecha \n 4:Izquierda \n 2:Abajo \n 8:Arriba \n 9:Diagonal superior derecha"
                + "\n 7:Diagonal superior izquierda \n 3:Diagonal inferior derecha \n 1:Diagonal inferior izquierda ");
        char direccion = sc.next().charAt(0);

        switch (direccion) {
            case '6':
                moverDerecha(pasos);
                break;
            case '4':
                moverIzquierda(pasos);
                break;
            case '2':
                moverAbajo(pasos);
                break;
            case '8':
                moverArriba(pasos);
                break;
            case '9':
                moverDiagonalSuperiorDerecha(pasos);
                break;
            case '7':
                moverDiagonalSuperiorIzquierda(pasos);
                break;
            case '3':
                moverDiagonalInferiorDerecha(pasos);
                break;
            case '1':
                moverDiagonalInferiorIzquierda(pasos);
                break;
            default:
                System.out.println("Dirección inválida.");
        }
    }

    /**
     * Mueve la tortuga hacia la derecha en la cantidad de pasos especificada.
     */
    public void moverDerecha(int pasos) {
        for (int i = x; i < x + pasos && i < Ancho; i++) {
            if (plumaAbajo) {
                tabla[y][i] = 1;
            }
        }
        x = Math.min(x + pasos, Ancho - 1);
    }

    /**
     * Mueve la tortuga hacia la izquierda en la cantidad de pasos especificada.
     */
    public void moverIzquierda(int pasos) {
        for (int i = x; i > x - pasos && i >= 0; i--) {
            if (plumaAbajo) {
                tabla[y][i] = 1;
            }
        }
        x = Math.max(x - pasos, 0);
    }

    /**
     * Mueve la tortuga hacia abajo en la cantidad de pasos especificada.
     */
    public void moverAbajo(int pasos) {
        for (int i = y; i < y + pasos && i < Alto; i++) {
            if (plumaAbajo) {
                tabla[i][x] = 1;
            }
        }
        y = Math.min(y + pasos, Alto - 1);
    }

    /**
     * Mueve la tortuga hacia arriba en la cantidad de pasos especificada.
     */
    public void moverArriba(int pasos) {
        for (int i = y; i > y - pasos && i >= 0; i--) {
            if (plumaAbajo) {
                tabla[i][x] = 1;
            }
        }
        y = Math.max(y - pasos, 0);
    }

    /**
     * Mueve la tortuga en diagonal superior derecha en la cantidad de pasos especificada.
     */
    public void moverDiagonalSuperiorDerecha(int pasos) {
        for (int i = 0; i < pasos && x + i < Ancho && y - i >= 0; i++) {
            if (plumaAbajo) {
                tabla[y - i][x + i] = 1;
            }
        }
        x = Math.min(x + pasos, Ancho - 1);
        y = Math.max(y - pasos, 0);
    }

    /**
     * Mueve la tortuga en diagonal superior izquierda en la cantidad de pasos especificada.
     */
    public void moverDiagonalSuperiorIzquierda(int pasos) {
        for (int i = 0; i < pasos && x - i >= 0 && y - i >= 0; i++) {
            if (plumaAbajo) {
                tabla[y - i][x - i] = 1;
            }
        }
        x = Math.max(x - pasos, 0);
        y = Math.max(y - pasos, 0);
    }

    /**
     * Mueve la tortuga en diagonal inferior derecha en la cantidad de pasos especificada.
     */
    public void moverDiagonalInferiorDerecha(int pasos) {
        for (int i = 0; i < pasos && x + i < Ancho && y + i < Alto; i++) {
            if (plumaAbajo) {
                tabla[y + i][x + i] = 1;
            }
        }
        x = Math.min(x + pasos, Ancho - 1);
        y = Math.min(y + pasos, Alto - 1);
    }

    /**
     * Mueve la tortuga en diagonal inferior izquierda en la cantidad de pasos especificada.
     */
    public void moverDiagonalInferiorIzquierda(int pasos) {
        for (int i = 0; i < pasos && x - i >= 0 && y + i < Alto; i++) {
            if (plumaAbajo) {
                tabla[y + i][x - i] = 1;
            }
        }
        x = Math.max(x - pasos, 0);
        y = Math.min(y + pasos, Alto - 1);
    }

    /**
     * Imprime el tablero actual con las posiciones de la tortuga y los valores
     * de las celdas.
     */
    public void imprimirTabla() {
        System.out.println("Dibujo:");

        // Imprimir encabezado de columnas
        System.out.print("   ");
        for (int i = 0; i < Ancho; i++) {
            System.out.printf("%3d", i);
        }
        System.out.println();

        // Imprimir borde superior
        System.out.print("  +");
        for (int i = 0; i < Ancho; i++) {
            System.out.print("---");
        }
        System.out.println();

        // Imprimir filas
        for (int i = 0; i < Alto; i++) {
            // Imprimir número de fila
            System.out.printf("%2d|", i);

            // Imprimir celdas
            for (int j = 0; j < Ancho; j++) {
                System.out.printf("%3d", tabla[i][j]);
            }

            System.out.println();
        }

        // Imprimir borde inferior
        System.out.print("  +");
        for (int i = 0; i < Ancho; i++) {
            System.out.print("---");
        }
        System.out.println();
    }

    /**
     * Imprime la posición actual y la dirección de la tortuga.
     */
    public void imprimirPosicionYDireccion() {
        System.out.printf("La tortuga está en la posición (%d, %d) ", y, x);
    }

    /**
     * Imprime los comandos disponibles para el usuario.
     */
    public void imprimirComandos() {
        System.out.println("Comandos:");
        System.out.println("1. Levantar Pluma");
        System.out.println("2. Bajar Pluma");
        System.out.println("3. Mover");
        System.out.println("4. Imprimir Tabla");
        System.out.println("5. Imprimir Posición");
        System.out.println("6. Comandos");
        System.out.println("7. Limpiar tablero");
        System.out.println("8. Borrar casilla");
        System.out.println("9. Archivo ejecutar");
        System.out.println("10. Crear archivo");
        System.out.println("11. Guardar");
        System.out.println("12. abrir archivo con la informacion guardada");
        System.out.println("0. Salir");
    }

    /**
     * Limpia todo el tablero, estableciendo a cero todos los valores de las
     * celdas.
     */
    public void limpiarTablero() {
        for (int i = 0; i < Alto; i++) {
            for (int j = 0; j < Ancho; j++) {
                tabla[i][j] = 0;
            }
        }
        System.out.println("Tablero limpiado.");
    }

    /**
     * Borra la casilla especificada por el usuario en el tablero.
     */
    public void borrarCasilla() {
        System.out.print("Ingrese la fila de la casilla a borrar: ");
        int fila = sc.nextInt();

        System.out.print("Ingrese la columna de la casilla a borrar: ");
        int columna = sc.nextInt();

        if (casillaValida(fila, columna)) {
            tabla[fila][columna] = 0;
            System.out.printf("Casilla en (%d, %d) borrada.\n", fila, columna);
        } else {
            System.out.println("Coordenadas fuera del rango. No se pudo borrar la casilla.");
        }
    }

    /**
     * Verifica si las coordenadas proporcionadas están dentro del rango del
     * tablero.
     *
     * @param fila La fila de la casilla.
     * @param columna La columna de la casilla.
     * @return true si las coordenadas están dentro del rango, false de lo
     * contrario.
     */
    public boolean casillaValida(int fila, int columna) {
        return fila >= 0 && fila < Alto && columna >= 0 && columna < Ancho;
    }

}