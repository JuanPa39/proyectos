package controlador;

import java.util.List;

public class Controlador {
    public static void main(String[] args) {
        ContactController contactController = new ContactController();

        // Agregar algunos contactos
        contactController.addContact("John Doe", "john.doe@example.com");
        contactController.addContact("Jane Smith", "jane.smith@example.com");

        // Obtener la lista de contactos
        List<Contact> contacts = contactController.getAllContacts();

        System.out.println("Lista de Contactos:");
        for (Contact contact : contacts) {
            System.out.println("Nombre: " + contact.getName() + ", Email: " + contact.getEmail());
        }

        // Eliminar un contacto
        if (!contacts.isEmpty()) {
            Contact contactToRemove = contacts.get(0);
            contactController.deleteContact(contactToRemove);
            System.out.println("Se ha eliminado el primer contacto.");
        } else {
            System.out.println("La lista de contactos está vacía.");
        }
    }
}
