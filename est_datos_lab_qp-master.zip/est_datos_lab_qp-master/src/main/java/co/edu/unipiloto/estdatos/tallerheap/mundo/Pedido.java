package co.edu.unipiloto.estdatos.tallerheap.mundo;

public class Pedido implements Comparable<Pedido> {

    private double precio;
    
    private String autorPedido;
    
    private int cercania;
 
    public Pedido(String autorPedido, double precio, int cercania) {
        this.autorPedido = autorPedido;
        this.precio = precio;
        this.cercania = cercania;
    }
    
    
    public double getPrecio() {
        return precio;
    }
    
    public String getAutorPedido() {
        return autorPedido;
    }
    
    public int getCercania() {
        return cercania;
    }

    @Override
    public int compareTo(Pedido otro) {
        return Double.compare(this.precio, otro.precio);
    }

    public int compareToCercania(Pedido otro) {
        return Integer.compare(this.cercania, otro.cercania); 
    }
    
    @Override
    public String toString() {
        return String.format("Pedido [Autor: %s, Precio: %.2f, Cercanía: %d]", autorPedido, precio, cercania);
    }
}
