/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package combsort;

public class CombSort {

    // Método principal que ordena el arreglo de enteros
    public static void sort(int[] a) {
        int n = a.length;
        int gap = n;
        boolean swapped = true;

        // Ciclo para reducir el gap y realizar intercambios
        while (gap != 1 || swapped) {
            // Obtener la nueva brecha (gap)
            gap = obtenerNuevaBrecha(gap);

            // Marcar que no se han hecho intercambios aún
            swapped = false;

            // Recorrer el arreglo y comparar elementos separados por gap
            for (int i = 0; i < n - gap; i++) {
                if (a[i] > a[i + gap]) {
                    // Intercambiar los elementos si están en el orden incorrecto
                    intercambiar(a, i, i + gap);
                    swapped = true;
                }
            }
        }
    }

    // Método para calcular la nueva brecha (gap)
    private static int obtenerNuevaBrecha(int gap) {
        gap = (gap * 10) / 13;
        return (gap < 1) ? 1 : gap;
    }

    // Método que intercambia dos elementos en el arreglo
    private static void intercambiar(int[] a, int i, int j) {
        int temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    // Método para verificar si el arreglo está ordenado
    public static boolean estaOrdenado(int[] a) {
        for (int i = 1; i < a.length; i++) {
            if (a[i] < a[i - 1]) {
                return false;
            }
        }
        return true;
    }

    // Método que imprime el contenido del arreglo
    public static void mostrar(int[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }

}
